-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : lun. 17 mars 2025 à 11:50
-- Version du serveur : 8.0.35
-- Version de PHP : 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `vrev_db_main_24`
--

-- --------------------------------------------------------

--
-- Structure de la table `EMPLOYE`
--

CREATE TABLE `EMPLOYE` (
  `ID_emp` int NOT NULL,
  `Nom_emp` varchar(50) NOT NULL,
  `Prenom_emp` varchar(50) NOT NULL,
  `Login_emp` varchar(50) NOT NULL,
  `Pass_emp` varchar(50) NOT NULL,
  `Admin_emp` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `EMPLOYE`
--

INSERT INTO `EMPLOYE` (`ID_emp`, `Nom_emp`, `Prenom_emp`, `Login_emp`, `Pass_emp`, `Admin_emp`) VALUES
(1, 'PERUS', 'Maxence', 'MPERUS', '3001', 1),
(2, 'MOKHTARI', 'Yasser', 'YMOKHTARI', '1312', 0),
(3, 'RIEDEL', 'Jean-Maxime', 'JRIEDEL', '1000', 0),
(4, 'DROGUE', 'Bruno', 'BDROGUE', '2000', 0);

-- --------------------------------------------------------

--
-- Structure de la table `ETAT_FRAIS`
--

CREATE TABLE `ETAT_FRAIS` (
  `ID_etat_frais` int NOT NULL,
  `lib_etat` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `ETAT_FRAIS`
--

INSERT INTO `ETAT_FRAIS` (`ID_etat_frais`, `lib_etat`) VALUES
(1, 'ATTENTE'),
(3, 'REFUSÉE'),
(2, 'REMBOURSER');

-- --------------------------------------------------------

--
-- Structure de la table `FRAIS`
--

CREATE TABLE `FRAIS` (
  `ID_frais` int NOT NULL,
  `ID_type_frais` int NOT NULL,
  `Descriptif_frais` varchar(255) DEFAULT NULL,
  `Date_frais` date NOT NULL,
  `ID_etat_frais` int NOT NULL,
  `Montant_frais` decimal(7,2) NOT NULL,
  `ID_emp` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `FRAIS`
--

INSERT INTO `FRAIS` (`ID_frais`, `ID_type_frais`, `Descriptif_frais`, `Date_frais`, `ID_etat_frais`, `Montant_frais`, `ID_emp`) VALUES
(1, 2, 'Repas Burger King', '2023-11-02', 1, 25.00, 1),
(2, 1, 'Hotel Ibis Budget', '2023-11-14', 2, 18.00, 2),
(3, 3, 'Déplacement Ecole', '2023-11-09', 3, 15.00, 3),
(4, 4, 'Péage Valence', '2023-11-13', 1, 8.50, 4);

-- --------------------------------------------------------

--
-- Structure de la table `TYPE_FRAIS`
--

CREATE TABLE `TYPE_FRAIS` (
  `ID_type_frais` int NOT NULL,
  `lib_frais` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `TYPE_FRAIS`
--

INSERT INTO `TYPE_FRAIS` (`ID_type_frais`, `lib_frais`) VALUES
(3, 'Carburant'),
(1, 'Hôtel'),
(4, 'Péage'),
(2, 'Restaurant');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `EMPLOYE`
--
ALTER TABLE `EMPLOYE`
  ADD PRIMARY KEY (`ID_emp`),
  ADD UNIQUE KEY `Pass_emp` (`Pass_emp`);

--
-- Index pour la table `ETAT_FRAIS`
--
ALTER TABLE `ETAT_FRAIS`
  ADD PRIMARY KEY (`ID_etat_frais`),
  ADD UNIQUE KEY `lib_etat` (`lib_etat`);

--
-- Index pour la table `FRAIS`
--
ALTER TABLE `FRAIS`
  ADD PRIMARY KEY (`ID_frais`),
  ADD KEY `ID_type_frais` (`ID_type_frais`),
  ADD KEY `ID_emp` (`ID_emp`),
  ADD KEY `ID_etat_frais` (`ID_etat_frais`);

--
-- Index pour la table `TYPE_FRAIS`
--
ALTER TABLE `TYPE_FRAIS`
  ADD PRIMARY KEY (`ID_type_frais`),
  ADD UNIQUE KEY `lib_frais` (`lib_frais`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `EMPLOYE`
--
ALTER TABLE `EMPLOYE`
  MODIFY `ID_emp` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `ETAT_FRAIS`
--
ALTER TABLE `ETAT_FRAIS`
  MODIFY `ID_etat_frais` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `FRAIS`
--
ALTER TABLE `FRAIS`
  MODIFY `ID_frais` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `TYPE_FRAIS`
--
ALTER TABLE `TYPE_FRAIS`
  MODIFY `ID_type_frais` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `FRAIS`
--
ALTER TABLE `FRAIS`
  ADD CONSTRAINT `frais_ibfk_1` FOREIGN KEY (`ID_type_frais`) REFERENCES `TYPE_FRAIS` (`ID_type_frais`),
  ADD CONSTRAINT `frais_ibfk_2` FOREIGN KEY (`ID_emp`) REFERENCES `EMPLOYE` (`ID_emp`),
  ADD CONSTRAINT `frais_ibfk_3` FOREIGN KEY (`ID_etat_frais`) REFERENCES `ETAT_FRAIS` (`ID_etat_frais`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
